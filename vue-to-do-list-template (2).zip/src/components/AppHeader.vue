<template>
  <div
    class="Header"
    style="font-family: 'Shadows Into Light', cursive; color: rgb(114, 238, 31);"
    id="h1"
  >
    <h1>To-do List:</h1>
  </div>
</template>

<script>
export default {
  name: "AppHeader"
};
</script>
