<template>
  <div>
    <span> {{ todo.text }} </span>
    <button
      v-on:click="removeTodo"
      id="button"
      style="background-color: #EFF1F4; color: red; font-size: 16px; padding: 1px 5px; border: green"
    >
      x
    </button>
  </div>
</template>

<script>
export default {
  name: "TodoItem",
  props: ["todo"],
  methods: {
    removeTodo() {
      this.$emit("todo:remove", this.todo.id);
    }
  }
};
</script>
