<template>
  <div>
    <input type="text" v-model="text" />
    <button
      v-on:click="addTodo"
      id="button"
      style="background-color: black; color: white; font-size: 16px; padding: 2px 10px; border: green"
    >
      Add
    </button>
  </div>
</template>

<script>
export default {
  name: "TodoInput",
  data() {
    return {
      text: ""
    };
  },
  methods: {
    addTodo() {
      this.$emit("todo:add", this.text);
      this.text = "";
    }
  }
};
</script>
